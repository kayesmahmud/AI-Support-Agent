# Contact Information

## Bulgaria Wants You Contact Details

**Address:**
22 Galichitsa St., Sofia 1164, Bulgaria
ул. „Галичица" №22, София 1164

**Phone:**
+359 877 496 777

**Email:**
office@bulgariawantsyou.com

**For Partnership Inquiries:**
For information about partnership packages for employers, institutions, and media partners, please contact: office@bulgariawantsyou.com

**Office Hours:**
Monday - Friday: 9:00 AM - 6:00 PM (EET/EEST)

## How to Reach Us

- **General Inquiries:** office@bulgariawantsyou.com
- **Employer Partnerships:** office@bulgariawantsyou.com
- **Technical Support:** office@bulgariawantsyou.com
- **Event Registration:** Register through your profile on the platform
