# Frequently Asked Questions

## What are your business hours?
Our support team is available Monday through Friday, 9 AM to 6 PM EST. For urgent issues outside these hours, please email urgent@company.com.

## How do I contact human support?
You can reach our human support team by:
- Email: support@company.com
- Phone: 1-800-XXX-XXXX
- Live chat: Click "Talk to Human" in this chat

## What is your response time?
We typically respond to inquiries within 24 hours on business days. Urgent issues are prioritized and usually addressed within 4 hours.

## Do you have a mobile app?
Yes! Our mobile app is available for both iOS and Android. Search for "[Your App Name]" in the App Store or Google Play.
